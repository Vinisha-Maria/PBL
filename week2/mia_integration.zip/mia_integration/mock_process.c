/* mock_process.c - stand-in for logger_process / core_process / ui_process.
 * Lets Mia test the launcher, control channel and cleanup BEFORE the real modules arrive.
 * It speaks the control protocol and deliberately leaves IPC objects behind, so the
 * launcher's cleanup can be verified.
 * Env: MOCK_CRASH_TARGET=<logger|core|ui> MOCK_CRASH_AFTER=<s>  (that process aborts)
 *      MOCK_UI_EXIT_AFTER=<s>                                    (UI exits normally)
 */
#define _GNU_SOURCE
#include "ipc_sock.h"
#include <fcntl.h>
#include <mqueue.h>
#include <semaphore.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

static volatile sig_atomic_t g_quit = 0;
static void on_shutdown(void) { g_quit = 1; }
static void on_sig(int s) { (void)s; g_quit = 1; }

int main(int argc, char **argv)
{
    (void)argc;
    const char *base = strrchr(argv[0], '/');
    base = base ? base + 1 : argv[0];
    char role[32];
    snprintf(role, sizeof role, "%s", base);
    char *us = strchr(role, '_');
    if (us) *us = '\0';                          /* logger_process -> logger */

    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);

    if (!strcmp(role, "logger")) mkfifo("/tmp/sim_log_fifo", 0600);
    if (!strcmp(role, "core")) {
        struct mq_attr at = { .mq_maxmsg = 10, .mq_msgsize = 64 };
        mq_open("/sim_cmd", O_CREAT | O_RDWR, 0600, &at);
        int fd = shm_open("/sim_state", O_CREAT | O_RDWR, 0600);
        if (fd >= 0) close(fd);
        sem_open("/sim_state_lock", O_CREAT, 0600, 1);
    }

    int fd = sock_ctrl_client_connect(role);
    if (fd < 0) { perror("mock: connect"); return 1; }
    sock_ctrl_send(fd, "READY");
    sock_ctrl_start_responder(fd, on_shutdown);

    const char *tgt = getenv("MOCK_CRASH_TARGET"), *ca = getenv("MOCK_CRASH_AFTER");
    const char *ue = getenv("MOCK_UI_EXIT_AFTER");
    int t = 0;
    while (!g_quit) {
        usleep(100 * 1000);
        t += 100;
        if (tgt && ca && !strcmp(tgt, role) && t >= atoi(ca) * 1000) abort();
        if (ue && !strcmp(role, "ui") && t >= atoi(ue) * 1000) return 0;
    }
    return 0;                                    /* exits WITHOUT unlinking IPC objects */
}

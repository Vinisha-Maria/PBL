# Integration Guide (Team Leader)

## Assumptions (check with the team)

1. `sock_ctrl_send/recv/close` take the socket **fd as first argument**, because the launcher holds three connections at once. All other names follow your spec.
2. Each member's binary is built from the file names in their prompt: `ui_process.c`, `core_process.c`, `logger_process.c`, `ipc_mq.c`, `ipc_shm.c`, `ipc_fifo.c`. Rename in the `Makefile` if yours differ.
3. For benchmarking, both the standalone simulator (`sim_standalone`) and the three-process simulator run **headless** when the environment variable `SIM_BENCH_TICKS=<N>` is set: simulate N ticks, then exit with code 0 (the UI quits by itself, so the launcher ends). Agree this with Rian and Varun.
4. The launcher does **not** auto-restart a crashed process. It shuts everything down cleanly and exits with code 1. "Restart" means running the launcher again.
5. Logger writes `sim_execution.log` and `sim_error.log` (as in Rajath's prompt).

## Files

| File | Purpose |
|---|---|
| `sim_types.h` | one shared definition of names, `struct sim_cmd`, `struct sim_state`, log-line limit (everyone includes it) |
| `ipc_sock.h/.c` | control channel (Unix domain socket) + `sock_ctrl_start_responder()` |
| `sim_launcher.c` | starts Logger -> Core -> UI, PING every 2 s, detects death/hang, SHUTDOWN, cleanup |
| `Makefile` | targets `all run test bench clean` (+ `mock`, `mocktest`) |
| `test_sock.c`, `test_integration.sh` | control-channel unit test, system tests T1-T5 |
| `bench_ipc.c`, `bench_runner.c`, `bench.sh` | benchmarks and CSV/summary script |
| `mock_process.c` | stand-in processes so you can test the launcher before the real modules arrive |
| `ARCHITECTURE.md`, `PERFORMANCE_ANALYSIS.md` | diagram description + Mermaid; results template + README outline |

## What each member must add to their `main()` (3 lines)

```c
#include "ipc_sock.h"
static void on_shutdown(void) { /* set your "quit" flag so main loop exits and you clean up */ }

/* ... after creating your IPC objects and starting your threads: */
int ctl = sock_ctrl_client_connect("ui");      /* "ui", "core" or "logger" - exactly these names */
sock_ctrl_send(ctl, "READY");
sock_ctrl_start_responder(ctl, on_shutdown);   /* answers PING, calls on_shutdown on SHUTDOWN */
```

Rules: send READY only **after** your IPC objects exist; exit with code 0 on shutdown; UI exits with code 0 when the user quits (the launcher then stops everything).

## Compile, run, test

```bash
make                  # builds everything (needs the members' .c files)
make mocktest         # control channel + launcher tests with mock processes (works today)
make run              # ./sim_launcher
make test             # test_sock + members' test_ipc_*.c + test_integration.sh
make bench            # ./bench.sh 10 100000  -> results_*.csv
./sim_launcher --cleanup   # remove leftover IPC objects after a crash
make clean
```

Members' own tests: name them `test_ipc_<anything>.c`; `make` builds them against all four modules.

## Integration checklist

Before integrating
- [ ] Everyone includes `sim_types.h`; no private copies of the structs or names
- [ ] Each module compiles alone with `-Wall -Wextra -pthread` with no warnings
- [ ] Each member's own IPC test passes (`make test`)
- [ ] Each process calls connect / READY / responder (3 lines above)

Integration
- [ ] `make` builds all binaries
- [ ] `./sim_launcher` prints `logger READY`, `core READY`, `ui READY`, `all processes READY`
- [ ] UI command (START) reaches Core (check Core log line)
- [ ] State shown in UI changes every tick (shared memory read works)
- [ ] Logger file has lines for commands, ticks, memory, stack, queue and errors
- [ ] Every log line matches `timestamp|LEVEL|SOURCE|message`

System tests (`./test_integration.sh`)
- [ ] T1 full flow, headless run exits 0, log not empty and well-formed, no leftovers
- [ ] T2 each module started alone does not crash or hang forever
- [ ] T3 `kill -9 core_process`: launcher stops all within 10 s, exit code non-zero, no stray processes, no leftovers
- [ ] T4 launcher can start again after the crash
- [ ] T5 Ctrl-C: stops in under 10 s, exit code 0, no stray processes, no leftovers

Deliverables
- [ ] Diagram (`ARCHITECTURE.md`) drawn and added to the repo
- [ ] Each member's IPC justification collected
- [ ] `make bench` run on the final build, results copied to `PERFORMANCE_ANALYSIS.md`
- [ ] README updated

## Most likely interface mismatches and how to detect them

| Mismatch | Symptom | How to detect |
|---|---|---|
| Struct defined twice with different fields or padding | garbage state in UI, `EMSGSIZE` from `mq_receive` | one `sim_types.h`; print `sizeof(struct sim_state)` and `sizeof(struct sim_cmd)` at startup in every process and compare; `_Static_assert` already in the header |
| Object name differs (missing leading `/`, typo, hard-coded) | one side gets `ENOENT`, other side waits forever | `grep -n '"/sim_\|sim_log_fifo\|sim_ctrl' *.c` must show only the `#define`s |
| `mq_msgsize` smaller than `sizeof(struct sim_cmd)`, or receive buffer smaller than `mq_msgsize` | `EMSGSIZE` | print attributes with `mq_getattr`; unit test sends every command type |
| Blocking calls: `mq_receive` with no timeout, FIFO `open(O_WRONLY)` with no reader, `sem_wait` forever | process cannot shut down, or Core freezes when Logger is absent | T2 and T5; `strace -f -p <pid>` shows where it is stuck; all waits must use timeouts or O_NONBLOCK |
| Cleanup ownership unclear (nobody, or two processes, unlink) | leftovers in `/dev/shm`, `/dev/mqueue`, `/tmp`; second run fails with `EEXIST` | leftovers check in T1/T3/T5; rule: creator uses `O_CREAT` **without** `O_EXCL`, treats `ENOENT/EEXIST` as normal; launcher unlinks everything at the end |
| Start-order race (UI opens shared memory before Core created it) | UI exits with `ENOENT` | T2; READY is sent only after objects exist; UI retries `shm_open` for a few seconds |
| Named semaphore vs unnamed semaphore mixed up | UI never wakes, or reads half-written state | check `ls /dev/shm` shows `sem.sim_state_lock`; both sides use `sem_open("/sim_state_lock")` |
| Log line too long, missing `\n`, or `\|` inside the message | Logger splits lines, merged lines, bad fields | T1 regex check; `SIM_LOG_LINE_MAX` 512 in `log_write` |
| SIGINT/SIGTERM handled differently | process ignores Ctrl-C, shutdown takes seconds, launcher has to SIGTERM/SIGKILL | T5 time and launcher messages `ignored SHUTDOWN`; each process must leave its main loop when `on_shutdown` fires |
| Missing `-pthread` / `-lrt` | link errors or silent thread problems | `make` uses the same flags for everyone; do not compile by hand |
| Process never sends READY / never answers PING | launcher says "did not connect", "never sent READY" or "hung" | launcher messages name the process |

## Short explanation for the viva

- **Why three processes?** Separation of responsibilities and isolation: a crash or slow disk in the Logger cannot freeze the simulation core; each part can be tested and replaced alone. The price is IPC overhead and more complex start-up and shutdown.
- **Why four different IPC techniques?** Each fits its traffic. Message queue: small discrete commands, kernel keeps message boundaries and order. Shared memory + semaphore: the state is big and read often, so no copying through the kernel; the semaphore protects consistency. FIFO: one-way stream of text lines, simplest for logging. Unix domain socket: two-way, connection-based, so the launcher can tell instantly when a process dies; ideal for control messages.
- **What does my launcher do?** Creates the control socket, starts Logger, Core, UI in that order (consumers before producers), waits for READY from each, sends PING every 2 s, treats a dead process or 3 missed PONGs as failure, then sends SHUTDOWN in reverse order (UI, Core, Logger, so logs are flushed last), escalates to SIGTERM/SIGKILL if needed, and finally unlinks every IPC object as a safety net.
- **How do I know cleanup works?** The mock processes deliberately leave objects behind; tests T3 and T5 prove the launcher removes them.
- **How do I measure overhead?** `bench_runner` runs the same headless workload 10 times on standalone and multi-process, recording wall time, CPU time (`wait4` rusage), and peak total memory (sum of VmRSS over the process tree). Overhead per tick is (multi - standalone) / ticks; `bench_ipc` gives per-message latency and throughput for each technique.
- **Limitation to admit:** `bench_ipc` measures a parent/child ping-pong with 64-byte messages, so results depend on the machine and scheduler; compare techniques relatively, and report mean and standard deviation over 10 runs.
